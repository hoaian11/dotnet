﻿namespace WebRauCu.Helpers
{
    public class MySetting
    {
        public static string CART_KEY = "MYCART";
    }
}