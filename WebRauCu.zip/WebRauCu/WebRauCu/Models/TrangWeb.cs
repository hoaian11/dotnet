﻿using System;
using System.Collections.Generic;

namespace WebRauCu.Models;

public partial class TrangWeb
{
    public int MaTrang { get; set; }

    public string TenTrang { get; set; } = null!;

    public string Url { get; set; } = null!;

    public virtual ICollection<PhanQuyen> PhanQuyens { get; } = new List<PhanQuyen>();
}
