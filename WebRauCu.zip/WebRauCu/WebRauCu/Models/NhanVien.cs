﻿using System;
using System.Collections.Generic;

namespace WebRauCu.Models;

public partial class NhanVien
{
    public string MaNv { get; set; } = null!;

    public string HoTen { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? MatKhau { get; set; }

    public virtual ICollection<ChuDe> ChuDes { get; } = new List<ChuDe>();

    public virtual ICollection<HoaDon> HoaDons { get; } = new List<HoaDon>();

    public virtual ICollection<HoiDap> HoiDaps { get; } = new List<HoiDap>();

    public virtual ICollection<PhanCong> PhanCongs { get; } = new List<PhanCong>();
}
