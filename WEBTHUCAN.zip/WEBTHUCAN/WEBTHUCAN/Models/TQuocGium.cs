﻿using System;
using System.Collections.Generic;

namespace WEBTHUCAN.Models;

public partial class TQuocGium
{
    public int MaNuoc { get; set; }

    public string? TenNuoc { get; set; }

    public virtual ICollection<TDanhMucSp> TDanhMucSps { get; } = new List<TDanhMucSp>();
}
