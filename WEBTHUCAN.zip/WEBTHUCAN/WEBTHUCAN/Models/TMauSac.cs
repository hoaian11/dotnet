﻿using System;
using System.Collections.Generic;

namespace WEBTHUCAN.Models;

public partial class TMauSac
{
    public int MaMauSac { get; set; }

    public string? TenMauSac { get; set; }

    public virtual ICollection<TChiTietSanPham> TChiTietSanPhams { get; } = new List<TChiTietSanPham>();
}
