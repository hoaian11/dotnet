﻿using System;
using System.Collections.Generic;

namespace WEBTHUCAN.Models;

public partial class TChiTietSanPham
{
    public int MaChiTietSp { get; set; }

    public int? MaSp { get; set; }

    public int? MaKichThuoc { get; set; }

    public int? MaMauSac { get; set; }

    public string? AnhDaiDien { get; set; }

    public string? Video { get; set; }

    public double? DonGiaBan { get; set; }

    public double? GiamGia { get; set; }

    public int? Slton { get; set; }

    public virtual TKichThuoc? MaKichThuocNavigation { get; set; }

    public virtual TMauSac? MaMauSacNavigation { get; set; }

    public virtual TDanhMucSp? MaSpNavigation { get; set; }

    public virtual ICollection<TAnhChiTietSp> TAnhChiTietSps { get; } = new List<TAnhChiTietSp>();

    public virtual ICollection<TChiTietHdb> TChiTietHdbs { get; } = new List<TChiTietHdb>();
}
