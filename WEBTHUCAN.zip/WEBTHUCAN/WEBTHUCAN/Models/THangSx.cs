﻿using System;
using System.Collections.Generic;

namespace WEBTHUCAN.Models;

public partial class THangSx
{
    public int MaHangSx { get; set; }

    public string? HangSx { get; set; }

    public int? MaNuocThuongHieu { get; set; }

    public virtual ICollection<TDanhMucSp> TDanhMucSps { get; } = new List<TDanhMucSp>();
}
