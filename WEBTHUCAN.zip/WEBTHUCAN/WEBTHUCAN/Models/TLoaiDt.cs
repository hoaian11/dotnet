﻿using System;
using System.Collections.Generic;

namespace WEBTHUCAN.Models;

public partial class TLoaiDt
{
    public int MaDt { get; set; }

    public string? TenLoai { get; set; }

    public virtual ICollection<TDanhMucSp> TDanhMucSps { get; } = new List<TDanhMucSp>();
}
