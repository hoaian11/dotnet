﻿using System;
using System.Collections.Generic;

namespace WEBTHUCAN.Models;

public partial class TChatLieu
{
    public int MaChatLieu { get; set; }

    public string? ChatLieu { get; set; }

    public virtual ICollection<TDanhMucSp> TDanhMucSps { get; } = new List<TDanhMucSp>();
}
