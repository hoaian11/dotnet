﻿using System;
using System.Collections.Generic;

namespace WEBTHUCAN.Models;

public partial class TLoaiSp
{
    public int MaLoai { get; set; }

    public string? Loai { get; set; }

    public virtual ICollection<TDanhMucSp> TDanhMucSps { get; } = new List<TDanhMucSp>();
}
