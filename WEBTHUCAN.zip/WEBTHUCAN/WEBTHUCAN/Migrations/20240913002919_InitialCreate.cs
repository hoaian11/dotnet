﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WEBTHUCAN.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tAnhSP",
                columns: table => new
                {
                    MaSP = table.Column<int>(type: "int", nullable: false),
                    TenFileAnh = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    ViTri = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tAnhSP__2FC2FB7E4613CD2C", x => new { x.MaSP, x.TenFileAnh });
                });

            migrationBuilder.CreateTable(
                name: "tChatLieu",
                columns: table => new
                {
                    MaChatLieu = table.Column<int>(type: "int", nullable: false),
                    ChatLieu = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tChatLie__453995BC7B6D7599", x => x.MaChatLieu);
                });

            migrationBuilder.CreateTable(
                name: "tHangSX",
                columns: table => new
                {
                    MaHangSX = table.Column<int>(type: "int", nullable: false),
                    HangSX = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    MaNuocThuongHieu = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tHangSX__8C6D28FEBDB6A42E", x => x.MaHangSX);
                });

            migrationBuilder.CreateTable(
                name: "tKichThuoc",
                columns: table => new
                {
                    MaKichThuoc = table.Column<int>(type: "int", nullable: false),
                    KichThuoc = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tKichThu__22BFD664BEE3DD21", x => x.MaKichThuoc);
                });

            migrationBuilder.CreateTable(
                name: "tLoaiDT",
                columns: table => new
                {
                    MaDT = table.Column<int>(type: "int", nullable: false),
                    TenLoai = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tLoaiDT__272586556B35682B", x => x.MaDT);
                });

            migrationBuilder.CreateTable(
                name: "tLoaiSP",
                columns: table => new
                {
                    MaLoai = table.Column<int>(type: "int", nullable: false),
                    Loai = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tLoaiSP__730A57595EB64AA6", x => x.MaLoai);
                });

            migrationBuilder.CreateTable(
                name: "tMauSac",
                columns: table => new
                {
                    MaMauSac = table.Column<int>(type: "int", nullable: false),
                    TenMauSac = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tMauSac__B9A91162632B3219", x => x.MaMauSac);
                });

            migrationBuilder.CreateTable(
                name: "tQuocGia",
                columns: table => new
                {
                    MaNuoc = table.Column<int>(type: "int", nullable: false),
                    TenNuoc = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tQuocGia__21306FEAC30D0CED", x => x.MaNuoc);
                });

            migrationBuilder.CreateTable(
                name: "tUser",
                columns: table => new
                {
                    username = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    password = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    LoaiUser = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tUser__F3DBC5732679640B", x => x.username);
                });

            migrationBuilder.CreateTable(
                name: "tDanhMucSP",
                columns: table => new
                {
                    MaSP = table.Column<int>(type: "int", nullable: false),
                    TenSP = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    MaChatLieu = table.Column<int>(type: "int", nullable: true),
                    NganLapTop = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    Model = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    CanNang = table.Column<double>(type: "float", nullable: true),
                    DoNoi = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    MaHangSX = table.Column<int>(type: "int", nullable: true),
                    MaNuocSX = table.Column<int>(type: "int", nullable: true),
                    MaDacTinh = table.Column<int>(type: "int", nullable: true),
                    Website = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    ThoiGianBaoHanh = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    GioiThieuSP = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ChietKhau = table.Column<double>(type: "float", nullable: true),
                    MaLoai = table.Column<int>(type: "int", nullable: true),
                    MaDT = table.Column<int>(type: "int", nullable: true),
                    AnhDaiDien = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    GiaNhoNhat = table.Column<double>(type: "float", nullable: true),
                    GiaLonNhat = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tDanhMuc__2725081C7B53E8F1", x => x.MaSP);
                    table.ForeignKey(
                        name: "FK__tDanhMucSP__MaDT__46E78A0C",
                        column: x => x.MaDT,
                        principalTable: "tLoaiDT",
                        principalColumn: "MaDT");
                    table.ForeignKey(
                        name: "FK__tDanhMucS__MaCha__4316F928",
                        column: x => x.MaChatLieu,
                        principalTable: "tChatLieu",
                        principalColumn: "MaChatLieu");
                    table.ForeignKey(
                        name: "FK__tDanhMucS__MaHan__440B1D61",
                        column: x => x.MaHangSX,
                        principalTable: "tHangSX",
                        principalColumn: "MaHangSX");
                    table.ForeignKey(
                        name: "FK__tDanhMucS__MaLoa__45F365D3",
                        column: x => x.MaLoai,
                        principalTable: "tLoaiSP",
                        principalColumn: "MaLoai");
                    table.ForeignKey(
                        name: "FK__tDanhMucS__MaNuo__44FF419A",
                        column: x => x.MaNuocSX,
                        principalTable: "tQuocGia",
                        principalColumn: "MaNuoc");
                });

            migrationBuilder.CreateTable(
                name: "tKhachHang",
                columns: table => new
                {
                    MaKhachHang = table.Column<int>(type: "int", nullable: false),
                    username = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    TenKhachHang = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    NgaySinh = table.Column<DateTime>(type: "date", nullable: true),
                    SoDienThoai = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    DiaChi = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    LoaiKhachHang = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AnhDaiDien = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    GhiChu = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tKhachHa__88D2F0E55FE55B81", x => x.MaKhachHang);
                    table.ForeignKey(
                        name: "FK__tKhachHan__usern__571DF1D5",
                        column: x => x.username,
                        principalTable: "tUser",
                        principalColumn: "username");
                });

            migrationBuilder.CreateTable(
                name: "tNhanVien",
                columns: table => new
                {
                    MaNhanVien = table.Column<int>(type: "int", nullable: false),
                    username = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    TenNhanVien = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    NgaySinh = table.Column<DateTime>(type: "date", nullable: true),
                    SoDienThoai1 = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    SoDienThoai2 = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    DiaChi = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    ChucVu = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    AnhDaiDien = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    GhiChu = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tNhanVie__77B2CA47FD007C02", x => x.MaNhanVien);
                    table.ForeignKey(
                        name: "FK__tNhanVien__usern__59FA5E80",
                        column: x => x.username,
                        principalTable: "tUser",
                        principalColumn: "username");
                });

            migrationBuilder.CreateTable(
                name: "tChiTietSanPham",
                columns: table => new
                {
                    MaChiTietSP = table.Column<int>(type: "int", nullable: false),
                    MaSP = table.Column<int>(type: "int", nullable: true),
                    MaKichThuoc = table.Column<int>(type: "int", nullable: true),
                    MaMauSac = table.Column<int>(type: "int", nullable: true),
                    AnhDaiDien = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    Video = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    DonGiaBan = table.Column<double>(type: "float", nullable: true),
                    GiamGia = table.Column<double>(type: "float", nullable: true),
                    SLTon = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tChiTiet__651D90579AD3683E", x => x.MaChiTietSP);
                    table.ForeignKey(
                        name: "FK__tChiTietS__MaKic__4E88ABD4",
                        column: x => x.MaKichThuoc,
                        principalTable: "tKichThuoc",
                        principalColumn: "MaKichThuoc");
                    table.ForeignKey(
                        name: "FK__tChiTietS__MaMau__4F7CD00D",
                        column: x => x.MaMauSac,
                        principalTable: "tMauSac",
                        principalColumn: "MaMauSac");
                    table.ForeignKey(
                        name: "FK__tChiTietSa__MaSP__4D94879B",
                        column: x => x.MaSP,
                        principalTable: "tDanhMucSP",
                        principalColumn: "MaSP");
                });

            migrationBuilder.CreateTable(
                name: "tHoaDonBan",
                columns: table => new
                {
                    MaHoaDon = table.Column<int>(type: "int", nullable: false),
                    NgayHoaDon = table.Column<DateTime>(type: "date", nullable: true),
                    MaKhachHang = table.Column<int>(type: "int", nullable: true),
                    MaNhanVien = table.Column<int>(type: "int", nullable: true),
                    TongTienHD = table.Column<double>(type: "float", nullable: true),
                    GiamGiaHD = table.Column<double>(type: "float", nullable: true),
                    PhuongThucThanhToan = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    MaSoThue = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    ThongTinThue = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true),
                    GhiChu = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tHoaDonB__835ED13BC71A8C66", x => x.MaHoaDon);
                    table.ForeignKey(
                        name: "FK__tHoaDonBa__MaKha__5CD6CB2B",
                        column: x => x.MaKhachHang,
                        principalTable: "tKhachHang",
                        principalColumn: "MaKhachHang");
                    table.ForeignKey(
                        name: "FK__tHoaDonBa__MaNha__5DCAEF64",
                        column: x => x.MaNhanVien,
                        principalTable: "tNhanVien",
                        principalColumn: "MaNhanVien");
                });

            migrationBuilder.CreateTable(
                name: "tAnhChiTietSP",
                columns: table => new
                {
                    MaChiTietSP = table.Column<int>(type: "int", nullable: false),
                    TenFileAnh = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    ViTri = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tAnhChiT__6DFA63353258432B", x => new { x.MaChiTietSP, x.TenFileAnh });
                    table.ForeignKey(
                        name: "FK__tAnhChiTi__MaChi__52593CB8",
                        column: x => x.MaChiTietSP,
                        principalTable: "tChiTietSanPham",
                        principalColumn: "MaChiTietSP");
                });

            migrationBuilder.CreateTable(
                name: "tChiTietHDB",
                columns: table => new
                {
                    MaHoaDon = table.Column<int>(type: "int", nullable: false),
                    MaChiTietSP = table.Column<int>(type: "int", nullable: false),
                    SoLuongBan = table.Column<int>(type: "int", nullable: true),
                    DonGiaBan = table.Column<double>(type: "float", nullable: true),
                    GiamGia = table.Column<double>(type: "float", nullable: true),
                    GhiChu = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tChiTiet__E50F083EDF02426F", x => new { x.MaHoaDon, x.MaChiTietSP });
                    table.ForeignKey(
                        name: "FK__tChiTietH__MaChi__619B8048",
                        column: x => x.MaChiTietSP,
                        principalTable: "tChiTietSanPham",
                        principalColumn: "MaChiTietSP");
                    table.ForeignKey(
                        name: "FK__tChiTietH__MaHoa__60A75C0F",
                        column: x => x.MaHoaDon,
                        principalTable: "tHoaDonBan",
                        principalColumn: "MaHoaDon");
                });

            migrationBuilder.CreateIndex(
                name: "IX_tChiTietHDB_MaChiTietSP",
                table: "tChiTietHDB",
                column: "MaChiTietSP");

            migrationBuilder.CreateIndex(
                name: "IX_tChiTietSanPham_MaKichThuoc",
                table: "tChiTietSanPham",
                column: "MaKichThuoc");

            migrationBuilder.CreateIndex(
                name: "IX_tChiTietSanPham_MaMauSac",
                table: "tChiTietSanPham",
                column: "MaMauSac");

            migrationBuilder.CreateIndex(
                name: "IX_tChiTietSanPham_MaSP",
                table: "tChiTietSanPham",
                column: "MaSP");

            migrationBuilder.CreateIndex(
                name: "IX_tDanhMucSP_MaChatLieu",
                table: "tDanhMucSP",
                column: "MaChatLieu");

            migrationBuilder.CreateIndex(
                name: "IX_tDanhMucSP_MaDT",
                table: "tDanhMucSP",
                column: "MaDT");

            migrationBuilder.CreateIndex(
                name: "IX_tDanhMucSP_MaHangSX",
                table: "tDanhMucSP",
                column: "MaHangSX");

            migrationBuilder.CreateIndex(
                name: "IX_tDanhMucSP_MaLoai",
                table: "tDanhMucSP",
                column: "MaLoai");

            migrationBuilder.CreateIndex(
                name: "IX_tDanhMucSP_MaNuocSX",
                table: "tDanhMucSP",
                column: "MaNuocSX");

            migrationBuilder.CreateIndex(
                name: "IX_tHoaDonBan_MaKhachHang",
                table: "tHoaDonBan",
                column: "MaKhachHang");

            migrationBuilder.CreateIndex(
                name: "IX_tHoaDonBan_MaNhanVien",
                table: "tHoaDonBan",
                column: "MaNhanVien");

            migrationBuilder.CreateIndex(
                name: "IX_tKhachHang_username",
                table: "tKhachHang",
                column: "username");

            migrationBuilder.CreateIndex(
                name: "IX_tNhanVien_username",
                table: "tNhanVien",
                column: "username");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tAnhChiTietSP");

            migrationBuilder.DropTable(
                name: "tAnhSP");

            migrationBuilder.DropTable(
                name: "tChiTietHDB");

            migrationBuilder.DropTable(
                name: "tChiTietSanPham");

            migrationBuilder.DropTable(
                name: "tHoaDonBan");

            migrationBuilder.DropTable(
                name: "tKichThuoc");

            migrationBuilder.DropTable(
                name: "tMauSac");

            migrationBuilder.DropTable(
                name: "tDanhMucSP");

            migrationBuilder.DropTable(
                name: "tKhachHang");

            migrationBuilder.DropTable(
                name: "tNhanVien");

            migrationBuilder.DropTable(
                name: "tLoaiDT");

            migrationBuilder.DropTable(
                name: "tChatLieu");

            migrationBuilder.DropTable(
                name: "tHangSX");

            migrationBuilder.DropTable(
                name: "tLoaiSP");

            migrationBuilder.DropTable(
                name: "tQuocGia");

            migrationBuilder.DropTable(
                name: "tUser");
        }
    }
}
