﻿using System;
namespace WEBTHUCAN.Datas
{
	public class Tchatlieu
	{
        public int MaChatLieu { get; set; }
        public string ChatLieuName { get; set; }
    }
}

