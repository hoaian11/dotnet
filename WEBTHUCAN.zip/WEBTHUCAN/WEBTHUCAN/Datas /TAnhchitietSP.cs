﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TAnhchitietSP
	{
        public int MaChiTietSP { get; set; }
        public string TenFileAnh { get; set; }
        public string ViTri { get; set; }
    }
}

