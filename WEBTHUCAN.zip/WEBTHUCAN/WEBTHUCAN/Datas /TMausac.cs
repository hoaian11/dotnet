﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TMausac
	{
        public int MaMauSac { get; set; }
        public string TenMauSac { get; set; }
    }
}

