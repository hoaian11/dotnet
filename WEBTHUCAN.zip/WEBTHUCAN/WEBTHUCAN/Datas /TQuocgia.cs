﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TQuocgia
	{
        public int MaNuoc { get; set; }
        public string TenNuoc { get; set; }
    }
}

