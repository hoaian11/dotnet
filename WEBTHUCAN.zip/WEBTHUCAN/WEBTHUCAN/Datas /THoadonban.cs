﻿using System;
namespace WEBTHUCAN.Datas
{
	public class THoadonban
	{
        public int MaHoaDon { get; set; }
        public DateTime NgayHoaDon { get; set; }
        public int MaKhachHang { get; set; }
        public int MaNhanVien { get; set; }
        public float TongTienHD { get; set; }
        public float GiamGiaHD { get; set; }
        public string PhuongThucThanhToan { get; set; }
        public string MaSoThue { get; set; }
        public string ThongTinThue { get; set; }
        public string GhiChu { get; set; }
    }
}

