﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TKhachhang
	{
        public int MaKhachHang { get; set; }
        public string Username { get; set; }
        public string TenKhachHang { get; set; }
        public DateTime NgaySinh { get; set; }
        public string SoDienThoai { get; set; }
        public string DiaChi { get; set; }
        public string LoaiKhachHang { get; set; }
        public string AnhDaiDien { get; set; }
        public string GhiChu { get; set; }
    }
}

