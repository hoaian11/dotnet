﻿using System;
namespace WEBTHUCAN.Datas
{
	public class THangSX
	{
        public int MaHangSX { get; set; }
        public string HangSXName { get; set; }
        public int MaNuocThuongHieu { get; set; }
    }
}

