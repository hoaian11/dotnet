﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TChitietHDB
	{
        public int MaHoaDon { get; set; }
        public int MaChiTietSP { get; set; }
        public int SoLuongBan { get; set; }
        public float DonGiaBan { get; set; }
        public float GiamGia { get; set; }
        public string GhiChu { get; set; }
    }
}

