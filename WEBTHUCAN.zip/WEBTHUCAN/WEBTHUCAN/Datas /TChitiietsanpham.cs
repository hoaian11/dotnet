﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TChitiietsanpham
	{
        public int MaChiTietSP { get; set; }
        public int MaSP { get; set; }
        public int MaKichThuoc { get; set; }
        public int MaMauSac { get; set; }
        public string AnhDaiDien { get; set; }
        public string Video { get; set; }
        public float DonGiaBan { get; set; }
        public float GiamGia { get; set; }
        public int SLTon { get; set; }
    }
}

