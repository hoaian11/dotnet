﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TDanhmucSP
	{
        public int MaSP { get; set; }
        public string TenSP { get; set; }
        public int MaChatLieu { get; set; }
        public string NganLapTop { get; set; }
        public string Model { get; set; }
        public float CanNang { get; set; }
        public string DoNoi { get; set; }
        public int MaHangSX { get; set; }
        public int MaNuocSX { get; set; }
        public int MaDacTinh { get; set; }
        public string Website { get; set; }
        public string ThoiGianBaoHanh { get; set; }
        public string GioiThieuSP { get; set; }
        public float ChietKhau { get; set; }
        public int MaLoai { get; set; }
        public int MaDT { get; set; }
        public string AnhDaiDien { get; set; }
        public float GiaNhoNhat { get; set; }
        public float GiaLonNhat { get; set; }
    }
}

