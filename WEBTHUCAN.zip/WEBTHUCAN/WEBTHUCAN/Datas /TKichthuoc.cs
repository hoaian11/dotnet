﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TKichthuoc
	{
        public int MaKichThuoc { get; set; }
        public string KichThuocName { get; set; }
    }
}

