﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TloaiSP
	{
        public int MaLoai { get; set; }
        public string Loai { get; set; }
    }
}

