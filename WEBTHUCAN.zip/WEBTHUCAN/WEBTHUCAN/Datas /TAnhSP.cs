﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TAnhSP
	{
        public int MaSP { get; set; }
        public string TenFileAnh { get; set; }
        public string ViTri { get; set; }
    }
}

