﻿using System;
namespace WEBTHUCAN.Datas
{
	public class TloaiDT
	{
        public int MaDT { get; set; }
        public string TenLoai { get; set; }
    }
}

